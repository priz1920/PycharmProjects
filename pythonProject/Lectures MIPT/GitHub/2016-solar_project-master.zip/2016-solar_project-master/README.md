# solar_project
Модель Солнечной системы на языке Python
